<?php
/**
 * Internationalization file for magic words for LinkTree extension
 */

$magicWords = array();

$magicWords['en'] = array(
	'linktree' => array( 0, 'linktree' ),
);
