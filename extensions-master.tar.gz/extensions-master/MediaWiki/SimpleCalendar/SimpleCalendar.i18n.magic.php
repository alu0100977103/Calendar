<?php
/**
 * Internationalization file for magic words.
 */

$magicWords = array();

$magicWords['en'] = array(
	'calendar' => array( 0, 'calendar' )
);
