<?php
/**
 * Internationalisation file for the UserLoginLog extension.
 *
 * @file
 * @ingroup Extensions
 */

$messages = array();

/** English */
$messages['en'] = array(
	'userloginlogpage'     => "User login log",
	'userloginlogpagetext' => "This is a log of events associated with users logging in or out of the wiki",
	'userlogin-success'    => "Login completed successfully",
	'userlogin-error'      => "Login failure from $2",
	'userlogin-logout'     => "Logout completed successfully",
	'userloginlogentry'    => "",
);
