<?php
/**
 * Internationalization file for magic words.
 */

$magicWords = array();

$magicWords['en'] = array(
	'odmap' => array( 0, 'odmap' )
);
