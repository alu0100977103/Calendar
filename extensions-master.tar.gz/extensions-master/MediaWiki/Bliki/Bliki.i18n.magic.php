<?php
/**
 * Internationalization file for magic words.
 */

$magicWords = array();

$magicWords['en'] = array(
	'tags' => array( 0, 'tags' ),
	'nextpost' => array( 0, 'nextpost' ),
	'prevpost' => array( 0, 'prevpost' ),
	'blogroll' => array( 0, 'blogroll' ),
);
