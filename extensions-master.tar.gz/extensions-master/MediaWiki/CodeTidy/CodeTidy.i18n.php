<?php
/**
 * Internationalisation for CodeTidy extension
 *
 * @author Aran Dunkley
 * @file
 * @ingroup Extensions
 */

$messages = array();

/** English
 * @author Dunkley
 */
$messages['en'] = array(
	'codetidy' => 'PHP Code Tidier',
);
