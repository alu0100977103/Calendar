<?php
$messages = array();

$messages['en'] = array(
	'tog-facebook-push-allow-OnEdit' => 'Post to my Facebook News Feed when I make an edit',
	'facebook-msg-OnEdit-short' => 'has updated $WIKINAME wiki ($SUMMARY)',
	'facebook-msg-OnEdit-link' => '$ARTICLENAME',
	'facebook-msg-OnEdit' => '$TEXT',
);

