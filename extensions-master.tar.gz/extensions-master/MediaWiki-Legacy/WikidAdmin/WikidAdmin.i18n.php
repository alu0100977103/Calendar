<?php
/**
 * Internationalisation for WikidAdmin extension
 *
 * @author Aran Dunkley
 * @file
 * @ingroup Extensions
 */

$messages = array();

/** English
 * @author Dunkley
 */
$messages['en'] = array(
	'wikidadmin' => "Robot administration",
);
