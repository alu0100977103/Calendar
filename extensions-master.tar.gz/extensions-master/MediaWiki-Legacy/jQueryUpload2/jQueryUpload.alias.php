<?php
/**
* Aliases for special pages
*
* @file
* @ingroup Extensions
*/

$specialPageAliases = array();

/** English (English) */
$specialPageAliases['en'] = array(
	'jQueryUpload' => array( 'jQueryUpload' ),
);
