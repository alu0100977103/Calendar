<div id="sidebar">
<?php dynamic_sidebar( 'Sidebar 1' ); ?>
</div><!-- end id:sidebar -->
</div><!-- end id:content -->
</div><!-- end id:container -->
