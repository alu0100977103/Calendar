<div id="footer">
<p><strong><?php bloginfo('name');?></strong> &copy; <?php echo date(__('Y','ml'));?> <?php _e('All Rights Reserved.','ml');?></p>
<p class="right">
	<span><a href="http://wpthemes.info/misty-look/" title="<?php _e('MistyLook WordPress Theme by Sadish Bala','ml');?>"><?php _e('Free WordPress Themes','ml');?></a> | <a href="http://www.freehostreview.com/" title="Free Web Space" target="_blank">Free Web Space</a></span>
</p>
<br class="clear" />
</div><!-- end id:footer -->
<?php wp_footer();?>

</body>
</html>