<?php get_header();?>
<div id="content">
<div id="content-main">
	<?php include_once(TEMPLATEPATH.'/notfound.php');?>
</div><!-- end id:content-main -->
<?php get_sidebar();?>
<?php get_footer();?>